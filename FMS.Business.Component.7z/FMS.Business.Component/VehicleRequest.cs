﻿using FMS.Data.Model;
using FMS.Data.Infrastructure;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq.Expressions;

namespace FMS.Business.Component
{
    public class VehicleRequest
    {
        #region Members

        /// <summary>
        /// Manage VehicleRequest
        /// </summary>
        private readonly IRepository<fmsVehicleRequest> _repository;

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dbContext"></param>
        public VehicleRequest(DbContext dbContext)
        {
            _repository = new Repository<fmsVehicleRequest>(dbContext, true);
        }

        #endregion

        #region Methods

        /// <summary>
        /// Gets role by id
        /// </summary>
        /// <param name="id">role id</param>
        /// <returns>A single role</returns>
        public fmsVehicleRequest Get(Guid id)
        {
            return _repository.Single(o => o.RequestGUID.Equals(id));
        }

        /// <summary>
        /// Finds VehicleRequest based on the given predicate
        /// </summary>
        /// <param name="predicate">where clause</param>
        /// <returns>A single VehicleRequest</returns>
        public fmsVehicleRequest Find(Expression<Func<fmsVehicleRequest, bool>> predicate)
        {
            return _repository.First(predicate);
        }

        /// <summary>
        /// Finds Roles based on the given predicate
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="predicate">where clause</param>
        /// <param name="start"></param>
        /// <returns>IEnumerable of units</returns>
        public IEnumerable<fmsVehicleRequest> Find(int start, int limit, Expression<Func<fmsVehicleRequest, bool>> predicate)
        {
            return _repository.Find(start, limit, predicate);
        }
       
        public IEnumerable<fmsVehicleRequest> FindAll( Expression<Func<fmsVehicleRequest, bool>> predicate)
        {
            return _repository.Find( predicate);
        }


        /// <summary>
        /// Gets all roles
        /// </summary>
        /// <returns>IEnumerable of roles</returns>
        public IEnumerable<fmsVehicleRequest> GetAll()
        {
            return _repository.GetAll();
        }

        /// <summary>
        /// Gets all role as paged
        /// </summary>
        /// <param name="page">page number</param>
        /// <param name="pageSize">page size</param>
        /// <returns>IEnumerable of roles</returns>
        public IEnumerable<fmsVehicleRequest> GetAll(int page, int pageSize)
        {
            return _repository.GetAll(page, pageSize);
        }
      
        public IEnumerable<fmsVehicleRequest> Find(Expression<Func<fmsVehicleRequest, bool>> predicate,
          Expression<Func<fmsVehicleRequest, DateTime>> orderPredicate)
        {
            return _repository.Find(predicate, orderPredicate);
        }
        public IEnumerable<fmsVehicleRequest> Find(Expression<Func<fmsVehicleRequest, DateTime>> orderPredicate)
        {
            return _repository.Find(orderPredicate);
        }

        /// <summary>
        /// Adds a new role
        /// </summary>
        /// <param name="role">role</param>
        public void AddNew(fmsVehicleRequest role)
        {
            _repository.Add(role);
            _repository.SaveChanges();
        }

        /// <summary>
        /// Edits a loaded role
        /// </summary>
        /// <param name="role">role</param>
        public void Edit(fmsVehicleRequest role)
        {
            _repository.Edit(role);
            _repository.SaveChanges();
        }

        /// <summary>
        /// Deletes role by id
        /// </summary>
        /// <param name="id">role id</param>
        public void Delete(Guid id)
        {
            _repository.Delete(o => o.RequestGUID.Equals(id));
            _repository.SaveChanges();
        }
        /// <summary>
        /// Deletes multiple roles
        /// </summary>
        /// <param name="predicate">where clause</param>
        public void Delete(Expression<Func<fmsVehicleRequest, bool>> predicate)
        {
            _repository.Delete(predicate);
            _repository.SaveChanges();
        }
        /// <summary>
        /// Gets role count
        /// </summary>
        /// <returns>count of entities</returns>
        public int Count()
        {
            return _repository.Count();
        }

        #endregion
    }
}
