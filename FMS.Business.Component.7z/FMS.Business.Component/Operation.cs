﻿using FMS.Data.Model;
using FMS.Data.Infrastructure;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq.Expressions;

namespace FMS.Business.Component
{
    public class Operation
    {
        #region Members

        /// <summary>
        /// Manage Operation
        /// </summary>
        private readonly IRepository<coreOperation> _repository;

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dbContext"></param>
        public Operation(DbContext dbContext)
        {
            _repository = new Repository<coreOperation>(dbContext, true);
        }

        #endregion

        #region Methods

        /// <summary>
        /// Gets operation by id
        /// </summary>
        /// <param name="id">operation id</param>
        /// <returns>A single operation</returns>
        public coreOperation Get(Guid id)
        {
            return _repository.Single(o => o.OperationGUID.Equals(id));
        }

        /// <summary>
        /// Gets all operations
        /// </summary>
        /// <returns>IEnumerable of operations</returns>
        public IEnumerable<coreOperation> GetAll()
        {
            return _repository.GetAll();
        }

        /// <summary>
        /// Gets all operation as paged
        /// </summary>
        /// <param name="page">page number</param>
        /// <param name="pageSize">page size</param>
        /// <returns>IEnumerable of operations</returns>
        public IEnumerable<coreOperation> GetAll(int page, int pageSize)
        {
            return _repository.GetAll(page, pageSize);
        }

        /// <summary>
        /// Finds Operation based on the given predicate
        /// </summary>
        /// <param name="predicate">where clause</param>
        /// <returns>A single Operation</returns>
        public coreOperation Find(Expression<Func<coreOperation, bool>> predicate)
        {
            return _repository.First(predicate);
        }

        /// <summary>
        /// Finds Operations based on the given predicate
        /// </summary>
        /// <param name="predicate">where clause</param>
        /// <returns>IEnumerable of Operations</returns>
        public IEnumerable<coreOperation> FindAll(Expression<Func<coreOperation, bool>> predicate)
        {
            return _repository.Find(predicate);
        }

        /// <summary>
        /// Adds a new operation
        /// </summary>
        /// <param name="operation">operation</param>
        public void AddNew(coreOperation operation)
        {
            _repository.Add(operation);
            _repository.SaveChanges();
        }

        /// <summary>
        /// Edits a loaded operation
        /// </summary>
        /// <param name="operation">operation</param>
        public void Edit(coreOperation operation)
        {
            _repository.Edit(operation);
            _repository.SaveChanges();
        }

        /// <summary>
        /// Deletes operation by id
        /// </summary>
        /// <param name="id">operation id</param>
        public void Delete(Guid id)
        {
            _repository.Delete(o => o.OperationGUID.Equals(id));
            _repository.SaveChanges();
        }

        /// <summary>
        /// Gets operation count
        /// </summary>
        /// <returns>count of entities</returns>
        public int Count()
        {
            return _repository.Count();
        }

        #endregion
    }
}
