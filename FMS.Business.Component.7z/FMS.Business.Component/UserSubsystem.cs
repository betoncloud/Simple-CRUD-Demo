﻿using FMS.Data.Model;
using FMS.Data.Infrastructure;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq.Expressions;

namespace FMS.Business.Component
{
    public class UserSubsystem
    {
        #region Members

        /// <summary>
        /// Manage UserSubsystem
        /// </summary>
        private readonly IRepository<coreUserSubsystem> _repository;

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dbContext"></param>
        public UserSubsystem(DbContext dbContext)
        {
            _repository = new Repository<coreUserSubsystem>(dbContext, true);
        }

        #endregion

        #region Methods

        /// <summary>
        /// Gets UserSubsystem by id
        /// </summary>
        /// <param name="id">UserSubsystem id</param>
        /// <returns>A single UserSubsystem</returns>
        public coreUserSubsystem Get(Guid id)
        {
            return _repository.Single(o => o.UserSubsystemGUID.Equals(id));
        }

        /// <summary>
        /// Finds User Subsystem based on the given predicate
        /// </summary>
        /// <param name="predicate">where clause</param>
        /// <returns>A single User Subsystem</returns>
        public coreUserSubsystem Find(Expression<Func<coreUserSubsystem, bool>> predicate)
        {
            return _repository.First(predicate);
        }

        /// <summary>
        /// Finds User Subsystems based on the given predicate
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="predicate">where clause</param>
        /// <param name="start"></param>
        /// <returns>IEnumerable of User Subsystems</returns>
        public IEnumerable<coreUserSubsystem> Find(int start, int limit, Expression<Func<coreUserSubsystem, bool>> predicate)
        {
            return _repository.Find(start, limit, predicate);
        }

        /// <summary>
        /// Gets all UserSubsystems
        /// </summary>
        /// <returns>IEnumerable of UserSubsystems</returns>
        public IEnumerable<coreUserSubsystem> GetAll()
        {
            return _repository.GetAll();
        }

        /// <summary>
        /// Gets all UserSubsystem as paged
        /// </summary>
        /// <param name="page">page number</param>
        /// <param name="pageSize">page size</param>
        /// <returns>IEnumerable of UserSubsystems</returns>
        public IEnumerable<coreUserSubsystem> GetAll(int page, int pageSize)
        {
            return _repository.GetAll(page, pageSize);
        }

        /// <summary>
        /// Adds a new UserSubsystem
        /// </summary>
        /// <param name="UserSubsystem">UserSubsystem</param>
        public void AddNew(coreUserSubsystem UserSubsystem)
        {
            _repository.Add(UserSubsystem);
            _repository.SaveChanges();
        }

        /// <summary>
        /// Edits a loaded UserSubsystem
        /// </summary>
        /// <param name="UserSubsystem">UserSubsystem</param>
        public void Edit(coreUserSubsystem UserSubsystem)
        {
            _repository.Edit(UserSubsystem);
            _repository.SaveChanges();
        }

        /// <summary>
        /// Deletes UserSubsystem by id
        /// </summary>
        /// <param name="id">UserSubsystem id</param>
        public void Delete(Guid id)
        {
            _repository.Delete(o => o.UserSubsystemGUID.Equals(id));
            _repository.SaveChanges();
        }

        /// <summary>
        /// Delete userSubsystem by the specified predicate
        /// </summary>
        /// <param name="predicate"></param>
        public void Delete(Expression<Func<coreUserSubsystem, bool>> predicate)
        {
            _repository.Delete(predicate);
        }

        /// <summary>
        /// Gets UserSubsystem count
        /// </summary>
        /// <returns>count of entities</returns>
        public int Count()
        {
            return _repository.Count();
        }

        #endregion
    }
}
