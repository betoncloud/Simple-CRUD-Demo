﻿using FMS.Data.Model;
using FMS.Data.Infrastructure;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;

namespace FMS.Business.Component
{
    public class Module
    {
        #region Members

        /// <summary>
        /// Manage Module
        /// </summary>
        private readonly IRepository<coreModule> _repository;
        private readonly DbSet<coreModule> _moduleDbSet;
        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dbContext"></param>
        public Module(DbContext dbContext)
        {
            _repository = new Repository<coreModule>(dbContext, true);
        }

        #endregion

        #region Methods

        /// <summary>
        /// Gets module by id
        /// </summary>
        /// <param name="id">module id</param>
        /// <returns>A single module</returns>
        public coreModule Get(Guid id)
        {
            return _repository.Single(o => o.ModuleGUID.Equals(id));
        }

        /// <summary>
        /// Gets all modules
        /// </summary>
        /// <returns>IEnumerable of modules</returns>
        public IEnumerable<coreModule> GetAll()
        {
            return _repository.GetAll();
        }

        /// <summary>
        /// Gets all module as paged
        /// </summary>
        /// <param name="page">page number</param>
        /// <param name="pageSize">page size</param>
        /// <returns>IEnumerable of modules</returns>
        public IEnumerable<coreModule> GetAll(int page, int pageSize)
        {
            return _repository.GetAll(page, pageSize);
        }

        /// <summary>
        /// Finds Module based on the given predicate
        /// </summary>
        /// <param name="predicate">where clause</param>
        /// <returns>A single Module</returns>
        public coreModule Find(Expression<Func<coreModule, bool>> predicate)
        {
            return _repository.First(predicate);
        }

        /// <summary>
        /// Finds Modules based on the given predicate
        /// </summary>
        /// <param name="predicate">where clause</param>
        /// <returns>IEnumerable of Modules</returns>
        public IEnumerable<coreModule> FindAll(Expression<Func<coreModule, bool>> predicate)
        {
            return _repository.Find(predicate);
        }

        /// <summary>
        /// Adds a new module
        /// </summary>
        /// <param name="module">module</param>
        public void AddNew(coreModule module)
        {
            _repository.Add(module);
            _repository.SaveChanges();
        }

        /// <summary>
        /// Edits a loaded module
        /// </summary>
        /// <param name="module">module</param>
        public void Edit(coreModule module)
        {
            _repository.Edit(module);
            _repository.SaveChanges();
        }

        /// <summary>
        /// Deletes module by id
        /// </summary>
        /// <param name="id">module id</param>
        public void Delete(Guid id)
        {
            _repository.Delete(o => o.ModuleGUID.Equals(id));
            _repository.SaveChanges();
        }

        public IEnumerable<object> GetModules(Guid subSystemId) =>
            (from u in _repository.Find((Expression<Func<coreModule, bool>>)(m => (!m.IsDeleted && (m.SubsystemGUID == subSystemId))))
             select new
             {
                 Id = u.ModuleGUID,
                 Name = u.Name
             });

        //public IEnumerable<object> GetModules(int start, int limit) =>
        //    (from u in _repository.Find<string>(start, limit, (Expression<Func<coreModule, bool>>)(m => !m.IsDeleted), (Expression<Func<coreModule, string>>)(m => m.Name))
        //     select new
        //     {
        //         Id = u.ModuleGUID,
        //         SubsystemId = u.SubsystemGUID,
        //         Subsystem = u.coreSubsystem.Name,
        //         Name = u.Name,
        //         Code = u.Code
        //     });

        public int GetTotalCount() =>
            this._repository.Count(m => !m.IsDeleted);

        public DbSet<coreModule> GetModuleDbSet =>
            this._moduleDbSet;

        /// <summary>
        /// Gets module count
        /// </summary>
        /// <returns>count of entities</returns>
        public int Count()
        {
            return _repository.Count();
        }

        #endregion
    }
}