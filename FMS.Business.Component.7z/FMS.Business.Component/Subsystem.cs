﻿using FMS.Data.Model;
using FMS.Data.Infrastructure;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq.Expressions;

namespace FMS.Business.Component
{
    public class Subsystem
    {
        #region Members

        /// <summary>
        /// Manage Subsystem
        /// </summary>
        private readonly IRepository<coreSubsystem> _repository;

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dbContext"></param>
        public Subsystem(DbContext dbContext)
        {
            _repository = new Repository<coreSubsystem>(dbContext, true);
        }

        #endregion

        #region Methods

        /// <summary>
        /// Gets subsystem by id
        /// </summary>
        /// <param name="id">subsystem id</param>
        /// <returns>A single subsystem</returns>
        public coreSubsystem Get(Guid id)
        {
            return _repository.Single(o => o.SubsystemGUID.Equals(id));
        }

        /// <summary>
        /// Finds Subsystem based on the given predicate
        /// </summary>
        /// <param name="predicate">where clause</param>
        /// <returns>A single Subsystem</returns>
        public coreSubsystem Find(Expression<Func<coreSubsystem, bool>> predicate)
        {
            return _repository.Single(predicate);
        }

        /// <summary>
        /// Finds Subsystems based on the given predicate
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="predicate">where clause</param>
        /// <param name="start"></param>
        /// <returns>IEnumerable of Subsystems</returns>
        public IEnumerable<coreSubsystem> Find(int start, int limit, Expression<Func<coreSubsystem, bool>> predicate)
        {
            return _repository.Find(start, limit, predicate);
        }

        /// <summary>
        /// Gets all subsystems
        /// </summary>
        /// <returns>IEnumerable of subsystems</returns>
        public IEnumerable<coreSubsystem> GetAll()
        {
            return _repository.GetAll();
        }

        /// <summary>
        /// Gets all subsystem as paged
        /// </summary>
        /// <param name="page">page number</param>
        /// <param name="pageSize">page size</param>
        /// <returns>IEnumerable of subsystems</returns>
        public IEnumerable<coreSubsystem> GetAll(int page, int pageSize)
        {
            return _repository.GetAll(page, pageSize);
        }

        /// <summary>
        /// Adds a new subsystem
        /// </summary>
        /// <param name="subsystem">subsystem</param>
        public void AddNew(coreSubsystem subsystem)
        {
            _repository.Add(subsystem);
            _repository.SaveChanges();
        }

        /// <summary>
        /// Edits a loaded subsystem
        /// </summary>
        /// <param name="subsystem">subsystem</param>
        public void Edit(coreSubsystem subsystem)
        {
            _repository.Edit(subsystem);
            _repository.SaveChanges();
        }

        /// <summary>
        /// Deletes subsystem by id
        /// </summary>
        /// <param name="id">subsystem id</param>
        public void Delete(Guid id)
        {
            _repository.Delete(o => o.SubsystemGUID.Equals(id));
            _repository.SaveChanges();
        }

        /// <summary>
        /// Gets subsystem count
        /// </summary>
        /// <returns>count of entities</returns>
        public int Count()
        {
            return _repository.Count();
        }

        #endregion
    }
}
