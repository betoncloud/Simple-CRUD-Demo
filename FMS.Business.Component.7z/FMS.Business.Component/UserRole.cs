﻿using FMS.Data.Infrastructure;
using FMS.Data.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq.Expressions;

namespace FMS.Business.Component
{
    public class UserRole
    {
        #region Members

        /// <summary>
        /// Manage UserRole
        /// </summary>
        private readonly IRepository<coreUserRole> _repository;

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dbContext"></param>
        public UserRole(DbContext dbContext)
        {
            _repository = new Repository<coreUserRole>(dbContext, true);
        }

        #endregion

        #region Methods

        /// <summary>
        /// Gets userRole by id
        /// </summary>
        /// <param name="id">userRole id</param>
        /// <returns>A single userRole</returns>
        public coreUserRole Get(Guid id)
        {
            return _repository.Single(o => o.UserRoleGUID.Equals(id));
        }

        /// <summary>
        /// Finds User Role based on the given predicate
        /// </summary>
        /// <param name="predicate">where clause</param>
        /// <returns>A single User Role</returns>
        public coreUserRole Find(Expression<Func<coreUserRole, bool>> predicate)
        {
            return _repository.Single(predicate);
        }

        /// <summary>
        /// Finds User Roles based on the given predicate
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="predicate">where clause</param>
        /// <param name="start"></param>
        /// <returns>IEnumerable of User Roles</returns>
        public IEnumerable<coreUserRole> Find(int start, int limit, Expression<Func<coreUserRole, bool>> predicate)
        {
            return _repository.Find(start, limit, predicate);
        }

        /// <summary>
        /// Gets all userRoles
        /// </summary>
        /// <returns>IEnumerable of userRoles</returns>
        public IEnumerable<coreUserRole> GetAll()
        {
            return _repository.GetAll();
        }

        /// <summary>
        /// Gets all userRole as paged
        /// </summary>
        /// <param name="page">page number</param>
        /// <param name="pageSize">page size</param>
        /// <returns>IEnumerable of userRoles</returns>
        public IEnumerable<coreUserRole> GetAll(int page, int pageSize)
        {
            return _repository.GetAll(page, pageSize);
        }

        /// <summary>
        /// Finds UserRoles based on the given predicate
        /// </summary>
        /// <param name="predicate">where clause</param>
        /// <returns>IEnumerable of UserRoles</returns>
        public IEnumerable<coreUserRole> FindAll(Expression<Func<coreUserRole, bool>> predicate)
        {
            return _repository.Find(predicate);
        }

        /// <summary>
        /// Adds a new userRole
        /// </summary>
        /// <param name="userRole">userRole</param>
        public void AddNew(coreUserRole userRole)
        {
            _repository.Add(userRole);
            _repository.SaveChanges();
        }

        /// <summary>
        /// Adds new list of rolePermissions
        /// </summary>
        /// <param name="userRoles">list of rolePermission</param>
        public void AddNew(List<coreUserRole> userRoles)
        {
            foreach (coreUserRole privilege in userRoles)
            {
                _repository.Add(privilege);
            }
            _repository.SaveChanges();
        }

        /// <summary>
        /// Edits a loaded userRole
        /// </summary>
        /// <param name="userRole">userRole</param>
        public void Edit(coreUserRole userRole)
        {
            _repository.Edit(userRole);
            _repository.SaveChanges();
        }

        /// <summary>
        /// Edits list of user roles 
        /// </summary>
        /// <param name="userRoles">list of userRoles</param>
        public void Edit(List<coreUserRole> userRoles)
        {
            foreach (coreUserRole privilege in userRoles)
            {
                _repository.Edit(privilege);
            }
            _repository.SaveChanges();
        }
        /// <summary>
        /// Deletes userRole by id
        /// </summary>
        /// <param name="id">userRole id</param>
        public void Delete(Guid id)
        {
            _repository.Delete(o => o.UserRoleGUID.Equals(id));
            _repository.SaveChanges();
        }

        /// <summary>
        /// Delete userRole by the specified predicate
        /// </summary>
        /// <param name="predicate"></param>
        public void Delete(Expression<Func<coreUserRole, bool>> predicate)
        {
            _repository.Delete(predicate);
        }

        /// <summary>
        /// Gets userRole count
        /// </summary>
        /// <returns>count of entities</returns>
        public int Count()
        {
            return _repository.Count();
        }

        #endregion
    }
}
