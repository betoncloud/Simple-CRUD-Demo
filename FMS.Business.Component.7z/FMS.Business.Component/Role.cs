﻿using FMS.Data.Model;
using FMS.Data.Infrastructure;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq.Expressions;

namespace FMS.Business.Component
{
    public class Role
    {
        #region Members

        /// <summary>
        /// Manage Role
        /// </summary>
        private readonly IRepository<coreRole> _repository;

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dbContext"></param>
        public Role(DbContext dbContext)
        {
            _repository = new Repository<coreRole>(dbContext, true);
        }

        #endregion

        #region Methods

        /// <summary>
        /// Gets role by id
        /// </summary>
        /// <param name="id">role id</param>
        /// <returns>A single role</returns>
        public coreRole Get(Guid id)
        {
            return _repository.Single(o => o.RoleGUID.Equals(id));
        }

        /// <summary>
        /// Finds Role based on the given predicate
        /// </summary>
        /// <param name="predicate">where clause</param>
        /// <returns>A single Role</returns>
        public coreRole Find(Expression<Func<coreRole, bool>> predicate)
        {
            return _repository.First(predicate);
        }

        /// <summary>
        /// Finds Roles based on the given predicate
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="predicate">where clause</param>
        /// <param name="start"></param>
        /// <returns>IEnumerable of units</returns>
        public IEnumerable<coreRole> Find(int start, int limit, Expression<Func<coreRole, bool>> predicate)
        {
            return _repository.Find(start, limit, predicate);
        }

        /// <summary>
        /// Gets all roles
        /// </summary>
        /// <returns>IEnumerable of roles</returns>
        public IEnumerable<coreRole> GetAll()
        {
            return _repository.GetAll();
        }

        /// <summary>
        /// Gets all role as paged
        /// </summary>
        /// <param name="page">page number</param>
        /// <param name="pageSize">page size</param>
        /// <returns>IEnumerable of roles</returns>
        public IEnumerable<coreRole> GetAll(int page, int pageSize)
        {
            return _repository.GetAll(page, pageSize);
        }

        /// <summary>
        /// Adds a new role
        /// </summary>
        /// <param name="role">role</param>
        public void AddNew(coreRole role)
        {
            _repository.Add(role);
            _repository.SaveChanges();
        }

        /// <summary>
        /// Edits a loaded role
        /// </summary>
        /// <param name="role">role</param>
        public void Edit(coreRole role)
        {
            _repository.Edit(role);
            _repository.SaveChanges();
        }

        /// <summary>
        /// Deletes role by id
        /// </summary>
        /// <param name="id">role id</param>
        public void Delete(Guid id)
        {
            _repository.Delete(o => o.RoleGUID.Equals(id));
            _repository.SaveChanges();
        }
        /// <summary>
        /// Deletes multiple roles
        /// </summary>
        /// <param name="predicate">where clause</param>
        public void Delete(Expression<Func<coreRole, bool>> predicate)
        {
            _repository.Delete(predicate);
            _repository.SaveChanges();
        }
        /// <summary>
        /// Gets role count
        /// </summary>
        /// <returns>count of entities</returns>
        public int Count()
        {
            return _repository.Count();
        }

        #endregion
    }
}
