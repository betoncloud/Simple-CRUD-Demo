﻿using FMS.Data.Model;
using FMS.Data.Infrastructure;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq.Expressions;

namespace FMS.Business.Component
{
    public class RolePermission
    {
        #region Members

        /// <summary>
        /// Manage RolePermission
        /// </summary>
        private readonly IRepository<coreRolePermission> _repository;

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dbContext"></param>
        public RolePermission(DbContext dbContext)
        {
            _repository = new Repository<coreRolePermission>(dbContext, true);
        }

        #endregion

        #region Methods

        /// <summary>
        /// Gets rolePermission by id
        /// </summary>
        /// <param name="id">rolePermission id</param>
        /// <returns>A single rolePermission</returns>
        public coreRolePermission Get(Guid id)
        {
            return _repository.Single(o => o.PermissionGUID.Equals(id));
        }

        /// <summary>
        /// Finds Role Permission based on the given predicate
        /// </summary>
        /// <param name="predicate">where clause</param>
        /// <returns>A single Role Permission</returns>
        public coreRolePermission Find(Expression<Func<coreRolePermission, bool>> predicate)
        {
            return _repository.Single(predicate);
        }

        /// <summary>
        /// Finds Role Permission based on the given predicate
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="predicate">where clause</param>
        /// <param name="start"></param>
        /// <returns>IEnumerable of Role Permissions</returns>
        public IEnumerable<coreRolePermission> Find(int start, int limit, Expression<Func<coreRolePermission, bool>> predicate)
        {
            return _repository.Find(start, limit, predicate);
        }

        /// <summary>
        /// Gets all rolePermissions
        /// </summary>
        /// <returns>IEnumerable of rolePermissions</returns>
        public IEnumerable<coreRolePermission> GetAll()
        {
            return _repository.GetAll();
        }

        /// <summary>
        /// Gets all rolePermission as paged
        /// </summary>
        /// <param name="page">page number</param>
        /// <param name="pageSize">page size</param>
        /// <returns>IEnumerable of rolePermissions</returns>
        public IEnumerable<coreRolePermission> GetAll(int page, int pageSize)
        {
            return _repository.GetAll(page, pageSize);
        }

        /// <summary>
        /// Finds RolePermissions based on the given predicate
        /// </summary>
        /// <param name="predicate">where clause</param>
        /// <returns>IEnumerable of RolePermissions</returns>
        public IEnumerable<coreRolePermission> FindAll(Expression<Func<coreRolePermission, bool>> predicate)
        {
            return _repository.Find(predicate);
        }

        /// <summary>
        /// Adds a new rolePermission
        /// </summary>
        /// <param name="rolePermission">rolePermission</param>
        public void AddNew(coreRolePermission rolePermission)
        {
            _repository.Add(rolePermission);
            _repository.SaveChanges();
        }

        /// <summary>
        /// Adds new list of rolePermissions
        /// </summary>
        /// <param name="rolePermissions">list of rolePermission</param>
        public void AddNew(List<coreRolePermission> rolePermissions)
        {
            foreach (coreRolePermission permission in rolePermissions)
            {
                _repository.Add(permission);
            }
            _repository.SaveChanges();
        }

        /// <summary>
        /// Edits a loaded rolePermission
        /// </summary>
        /// <param name="rolePermission">rolePermission</param>
        public void Edit(coreRolePermission rolePermission)
        {
            _repository.Edit(rolePermission);
            _repository.SaveChanges();
        }

        /// <summary>
        /// Edits list of rolePermissions
        /// </summary>
        /// <param name="rolePermissions">list of rolePermissions</param>
        public void Edit(List<coreRolePermission> rolePermissions)
        {
            foreach (coreRolePermission permission in rolePermissions)
            {
                _repository.Edit(permission);
            }
            _repository.SaveChanges();
        }
        /// <summary>
        /// Deletes rolePermission by id
        /// </summary>
        /// <param name="id">rolePermission id</param>
        public void Delete(Guid id)
        {
            _repository.Delete(o => o.PermissionGUID.Equals(id));
            _repository.SaveChanges();
        }

        /// <summary>
        /// Delete rolePermission by the specified predicate
        /// </summary>
        /// <param name="predicate"></param>
        public void Delete(Expression<Func<coreRolePermission, bool>> predicate)
        {
            _repository.Delete(predicate);
        }

        /// <summary>
        /// Gets rolePermission count
        /// </summary>
        /// <returns>count of entities</returns>
        public int Count()
        {
            return _repository.Count();
        }

        #endregion
    }
}
