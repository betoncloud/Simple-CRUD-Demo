﻿using FMS.Data.Model;
using FMS.Data.Infrastructure;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq.Expressions;

namespace FMS.Business.Component
{
    public class User
    {
        #region Members

        /// <summary>
        /// Manage User
        /// </summary>
        private readonly IRepository<coreUser> _repository;

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dbContext"></param>
        public User(DbContext dbContext)
        {
            _repository = new Repository<coreUser>(dbContext, true);
        }

        #endregion

        #region Methods

        /// <summary>
        /// Gets user by id
        /// </summary>
        /// <param name="id">user id</param>
        /// <returns>A single user</returns>
        public coreUser Get(Guid id)
        {
            return _repository.Single(u => u.UserGUID.Equals(id));
        }

        /// <summary>
        /// Finds User based on the given predicate
        /// </summary>
        /// <param name="predicate">where clause</param>
        /// <returns>A single User</returns>
        public coreUser Find(Expression<Func<coreUser, bool>> predicate)
        {
            return _repository.Single(predicate);
        }

        /// <summary>
        /// Finds Users based on the given predicate
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="predicate">where clause</param>
        /// <param name="start"></param>
        /// <returns>IEnumerable of users</returns>
        public IEnumerable<coreUser> Find(int start, int limit, Expression<Func<coreUser, bool>> predicate)
        {
            return _repository.Find(start, limit, predicate);
        }

        /// <summary>
        /// Gets all users
        /// </summary>
        /// <returns>IEnumerable of users</returns>
        public IEnumerable<coreUser> GetAll()
        {
            return _repository.GetAll();
        }

        /// <summary>
        /// Gets all user as paged
        /// </summary>
        /// <param name="page">page number</param>
        /// <param name="pageSize">page size</param>
        /// <returns>IEnumerable of users</returns>
        public IEnumerable<coreUser> GetAll(int page, int pageSize)
        {
            return _repository.GetAll(page, pageSize);
        }

        /// <summary>
        /// Adds a new user
        /// </summary>
        /// <param name="user">user</param>
        public void AddNew(coreUser user)
        {
            _repository.Add(user);
            _repository.SaveChanges();
        }

        /// <summary>
        /// Edits a loaded user
        /// </summary>
        /// <param name="user">user</param>
        public void Edit(coreUser user)
        {
            _repository.Edit(user);
            _repository.SaveChanges();
        }

        /// <summary>
        /// Deletes user by id
        /// </summary>
        /// <param name="id">user id</param>
        public void Delete(Guid id)
        {
            _repository.Delete(o => o.UserGUID.Equals(id));
            _repository.SaveChanges();
        }

        /// <summary>
        /// Delete users by the specified predicate
        /// </summary>
        /// <param name="predicate">where clause</param>
        public void Delete(Expression<Func<coreUser, bool>> predicate)
        {
            _repository.Delete(predicate);
        }
        /// <summary>
        /// Gets user count
        /// </summary>
        /// <returns>count of entities</returns>
        public int Count()
        {
            return _repository.Count();
        }

        #endregion
    }
}
