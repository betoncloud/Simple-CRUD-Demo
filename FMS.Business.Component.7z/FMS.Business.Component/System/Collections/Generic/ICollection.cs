﻿namespace System.Collections.Generic
{
    internal interface ICollection
    {
    }
}