﻿using System.Collections.Generic;
using System.Data.Objects;
using System;
using System.Data.Entity;
using FMS.Data.Infrastructure;

namespace FMS.Business.Component
{
    public class Lookups
    {
        #region Members

        private readonly Repository _repository;

        #endregion

        #region Constructor

        public Lookups(DbContext objectContext)
        {
            _repository = new Repository(objectContext);
        }

        #endregion

        #region Methods

        public void AddNew(Lookup lookup, string table, string userName)
        {
            lookup.CreatedDate = DateTime.Now;
            lookup.ModifiedDate = DateTime.Now;
            _repository.Add(lookup, table, userName);
        }

        public void Edit(Lookup lookup, string table, string userName)
        {
            lookup.ModifiedDate = DateTime.Now;
            _repository.Edit(lookup, table, userName);
        }

        public void Delete(Guid id, string table)
        {
            _repository.Delete(id, table);
        }

        public Lookup Get(Guid id, string table)
        {
            return _repository.Get(id, table);
        }

        public Lookup GetRecord(Guid id, string table)
        {
            return _repository.GetRecord(id, table);
        }

        public IEnumerable<Lookup> GetAll(string table)
        {
            return _repository.GetAll(table);
        }

        public IEnumerable<Lookup> GetAll(int start, int limit, string table)
        {
            return _repository.GetAll(start, limit, table);
        }

        #endregion
    }
}