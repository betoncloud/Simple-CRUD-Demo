﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Data.Entity;

namespace FMS.Data.Infrastructure
{
    public class Repository<TEntity> : IRepository<TEntity> where TEntity : class, new()
    {
        #region Members

        private DbContext _dbContext;
        private readonly IDbSet<TEntity> _dbSet;

        #endregion

        #region Constructor

        public Repository(DbContext dbContext)
        {
            _dbContext = dbContext;
            _dbSet = _dbContext.Set<TEntity>();
            dbContext.Configuration.LazyLoadingEnabled = true;
        }

        public Repository(DbContext dbContext, bool lazyLoadingEnabled)
        {
            _dbContext = dbContext;
            _dbSet = _dbContext.Set<TEntity>();
            _dbContext.Configuration.LazyLoadingEnabled = true;
        }

        #endregion

        #region Methods

        public void SaveChanges()
        {
            _dbContext.SaveChanges();
        }
        
        public void Add(TEntity entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }
            _dbSet.Add(entity);
        }

        public void Edit(TEntity entity)
        {
            _dbSet.Attach(entity);
            _dbContext.Entry(entity).State = EntityState.Modified;
        }

        public void Delete(TEntity entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }
            _dbSet.Remove(entity);
        }

        public void Delete(Expression<Func<TEntity, bool>> predicate)
        {
            var records = Find(predicate);
            foreach (var record in records)
            {
                Delete(record);
            }
        }

        public void DeleteRelatedEntities(TEntity entity)
        {
            //if (entity == null)
            //{
            //    throw new ArgumentNullException("entity");
            //}
            //var relatedEntities =
            //    ((IEntityWithRelationships)entity).RelationshipManager.GetAllRelatedEnds().SelectMany(
            //        e => e.CreateSourceQuery().OfType<TEntity>()).ToList();
            //foreach (var relatedEntity in relatedEntities)
            //{
            //    _dbSet.Remove(relatedEntity);
            //}
            //_dbSet.Remove(entity);
        }

        public IQueryable<TEntity> GetAll()
        {
            return _dbSet.AsQueryable();
        }

        public IQueryable<TEntity> GetAll(int start, int limit)
        {
            return _dbSet.AsQueryable().Skip(start).Take(limit);
        }

        public IQueryable<TEntity> Find(Expression<Func<TEntity, bool>> predicate)
        {
            return _dbSet.Where(predicate).AsQueryable();
        }
        public IQueryable<TEntity> Find(int start, int limit, Expression<Func<TEntity, bool>> predicate)
        {
            return _dbSet.Where(predicate).Skip(start).Take(limit).AsQueryable();
        }

       



        public IQueryable<TEntity> FindAll( Expression<Func<TEntity, bool>> predicate)
        {
            return _dbSet.Where(predicate).AsQueryable();
        }

        public IQueryable<TEntity> Find<Ttype>( Expression<Func<TEntity, bool>> predicate,Expression<Func<TEntity, Ttype>> orderPredicate)
        {
            return _dbSet.Where(predicate).OrderByDescending(orderPredicate).AsQueryable();
        }
        public IQueryable<TEntity> Find<Ttype>(Expression<Func<TEntity, Ttype>> orderPredicate)
        {
            return _dbSet.OrderByDescending(orderPredicate).AsQueryable();
        }
       
    

       

        public TEntity Single(Expression<Func<TEntity, bool>> predicate)
        {
            return _dbSet.SingleOrDefault(predicate);
        }

        public TEntity Single()
        {
            return _dbSet.SingleOrDefault();
        }

        public TEntity First(Expression<Func<TEntity, bool>> predicate)
        {
            return _dbSet.FirstOrDefault(predicate);
        }

        public int Count()
        {
            return _dbSet.Count();
        }

        public int Count(Expression<Func<TEntity, bool>> predicate)
        {
            return _dbSet.Where(predicate).Count();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposing) return;
            if (_dbContext == null) return;
            _dbContext.Dispose();
            _dbContext = null;
        }

        #endregion

        #region Getters

        public DbContext Context
        {
            get
            {
                return _dbContext;
            }
        }
        #endregion
    }

    public class Repository
    {
        #region Members

        private readonly DbContext _dbContext;

        #endregion

        #region Constructor

        public Repository(DbContext dbContext)
        {
            _dbContext = dbContext;
        }

        #endregion

        #region Methods

        public void Add(Lookup lookup, string table, string userName)
        {
            var commandText = string.Format("Insert into {0} (Id, Name, Code, Priority, IsDeleted, CreatedBy, CreatedDate, LastModifiedBy, LastModifiedDate) Values('{1}', '{2}', '{3}', {4}, {5},'{6}','{7}','{8}', '{9}')", 
                table, lookup.Id, lookup.Name, lookup.Code, lookup.Priority, 0, userName, lookup.CreatedDate, userName, lookup.ModifiedDate);
            _dbContext.Database.ExecuteSqlCommand(commandText);
        }

        public void Edit(Lookup lookup, string table, string userName)
        {
            var commandText = string.Format("Update {0} Set Name='{1}', Code='{2}', LastModifiedBy='{3}', LastModifiedDate='{4}' Where Id='{5}'", 
                table, lookup.Name, lookup.Code, userName, lookup.ModifiedDate,lookup.Id);
            _dbContext.Database.ExecuteSqlCommand(commandText);
        }

        public void Delete(Guid id, string table)
        {
            var commandText = string.Format("Delete {0} Where Id='{1}'", table, id);
            _dbContext.Database.ExecuteSqlCommand(commandText);
        }

        public Lookup Get(Guid id, string table)
        {
            var commandText = string.Format("Select * From {0} Where Id='{1}'", table, id);
            return _dbContext.Database.SqlQuery<Lookup>(commandText).SingleOrDefault();
        }

        public Lookup GetRecord(Guid id, string table)
        {
            var commandText = string.Format("Select * From {0} Where Id='{1}'", table, id);
            return _dbContext.Database.SqlQuery<Lookup>(commandText).SingleOrDefault();
        }
        public IEnumerable<Lookup> GetAll(string table)
        {
            var commandText = string.Format("Select * from {0}", table);
            return _dbContext.Database.SqlQuery<Lookup>(commandText).ToList();
        }

        public IEnumerable<Lookup> GetAll(int start, int limit, string table)
        {
            var commandText = string.Format("Select * from {0}", table);
            return _dbContext.Database.SqlQuery<Lookup>(commandText).Skip(start).Take(limit);
        }

        #endregion
    }

    public class Lookup
    {
        #region Properties

        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool IsDeleted { get; set; }
        public Int16 Priority { get; set; }

        #endregion
    }
}
