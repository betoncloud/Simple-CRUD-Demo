﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;

namespace FMS.Data.Infrastructure
{
    public interface IRepository<TEntity> : IDisposable where TEntity : class, new()
    {
        #region Methods

        void SaveChanges();
        void Add(TEntity entity);
        void Edit(TEntity entity);
        void Delete(TEntity entity);        
        void Delete(Expression<Func<TEntity, bool>> predicate);
        void DeleteRelatedEntities(TEntity entity);
        IQueryable<TEntity> GetAll();    
        IQueryable<TEntity> GetAll(int start, int limit);
        IQueryable<TEntity> Find(int start, int limit, Expression<Func<TEntity, bool>> predicate);
        IQueryable<TEntity> Find(Expression<Func<TEntity, bool>> predicate);        
        IQueryable<TEntity> Find<Ttype>(Expression<Func<TEntity, bool>> predicate, Expression<Func<TEntity, Ttype>> orderPredicate);
        IQueryable<TEntity> Find<Ttype>(Expression<Func<TEntity, Ttype>> orderPredicate);               
        TEntity Single(Expression<Func<TEntity, bool>> predicate);
        TEntity First(Expression<Func<TEntity, bool>> predicate); 
        int Count();   
        int Count(Expression<Func<TEntity, bool>> predicate);

        #endregion

        #region Getters

        DbContext Context { get; }

        #endregion
    }
}
